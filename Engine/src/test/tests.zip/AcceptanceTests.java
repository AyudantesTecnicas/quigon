import driver.ConcreteGameDriver;
import driver.GameDriver;
import driver.GameLoadFailedException;
import driver.GameState;
import org.junit.Test;

import static org.junit.Assert.*;

public class AcceptanceTests {
    @Test
    public void shouldLostIfDownloadStairs() throws GameLoadFailedException {
        GameDriver driver = new ConcreteGameDriver();
        driver.initGame("F:\\GitHub\\quigon\\EntregaBuilder\\build\\libs\\EntregaBuilder.jar");
        driver.sendCommand("goto BibliotecaAcceso");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto Salon3");
        driver.sendCommand("pick Llave");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto Salon1");
        driver.sendCommand("move CuadroBarco");
        driver.sendCommand("open CajaFuerte using Llave");
        driver.sendCommand("pick Credencial");
        driver.sendCommand("put Foto in Credencial");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto BibliotecaAcceso");
        driver.sendCommand("show Credencial in Bibliotecario");
        driver.sendCommand("goto Biblioteca");
        driver.sendCommand("move LibroViejo");
        driver.sendCommand("goto Sotano");
        driver.sendCommand("use Escalera");
        assertEquals(GameState.Lost, driver.getCurrentState());
    }

    @Test
    public void shouldLostIfGoToBasementWithoutAHammer() throws GameLoadFailedException {
        GameDriver driver = new ConcreteGameDriver();
        driver.initGame("F:\\GitHub\\quigon\\EntregaBuilder\\build\\libs\\EntregaBuilder.jar");
        driver.sendCommand("goto BibliotecaAcceso");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto Salon3");
        driver.sendCommand("pick Llave");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto Salon1");
        driver.sendCommand("move CuadroBarco");
        driver.sendCommand("open CajaFuerte using Llave");
        driver.sendCommand("pick Credencial");
        driver.sendCommand("put Foto in Credencial");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto BibliotecaAcceso");
        driver.sendCommand("show Credencial in Bibliotecario");
        driver.sendCommand("goto Biblioteca");
        driver.sendCommand("move LibroViejo");
        driver.sendCommand("goto Sotano");
        driver.sendCommand("use Baranda");
        assertEquals(GameState.Lost, driver.getCurrentState());
    }

    @Test
    public void shouldWinIfGoToBasementWithAHammer() throws GameLoadFailedException {
        GameDriver driver = new ConcreteGameDriver();
        driver.initGame("F:\\GitHub\\quigon\\EntregaBuilder\\build\\libs\\EntregaBuilder.jar");
        driver.sendCommand("goto BibliotecaAcceso");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto Salon3");
        driver.sendCommand("pick Llave");
        driver.sendCommand("goto Salon2");
        driver.sendCommand("pick Martillo");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto Salon1");
        driver.sendCommand("move CuadroBarco");
        driver.sendCommand("open CajaFuerte using Llave");
        driver.sendCommand("pick Credencial");
        driver.sendCommand("put Foto in Credencial");
        driver.sendCommand("goto Pasillo");
        driver.sendCommand("goto BibliotecaAcceso");
        driver.sendCommand("show Credencial in Bibliotecario");
        driver.sendCommand("goto Biblioteca");
        driver.sendCommand("move LibroViejo");
        driver.sendCommand("goto Sotano");
        driver.sendCommand("use Baranda");
        driver.sendCommand("break Ventana using Martillo");
        driver.sendCommand("goto afuera");
        assertEquals(GameState.Won, driver.getCurrentState());
    }
}
